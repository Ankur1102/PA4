/**
 * 
 */
package simpledb;

/**
 * @author admin
 *
 */
public class LockManager {

}
